double mul_speed = 1.15;

double high_speed = 80 * mul_speed;
double mid_speed = 50 * mul_speed;
double low_speed = 25 * mul_speed;

int ESCAPE_SPEED = 220;

// Pines de los motores (L298N)
#define speedPinR 9
#define RightMotorDirPin1  22
#define RightMotorDirPin2  24
#define LeftMotorDirPin1  26
#define LeftMotorDirPin2  28
#define speedPinL 10

#define speedPinRB 11
#define RightMotorDirPin1B  5
#define RightMotorDirPin2B 6
#define LeftMotorDirPin1B 7
#define LeftMotorDirPin2B 8
#define speedPinLB 12

// Pines del sensor de ultrasonido
#define Echo_PIN    31
#define Trig_PIN    30

// Pines de los sensores de línea infrarrojos
#define sensor1   A4
#define sensor2   A3
#define sensor3   A2
#define sensor4   A1
#define sensor5   A0

// Distancia de ataque
const int distancelimit = 50;

// Variables para la "Memoria" del sensor
int ultima_distancia = 999;
int contador_perdidos = 0;
bool deteccion_confirmada = false;

void setup() {
  pinMode(RightMotorDirPin1, OUTPUT);
  pinMode(RightMotorDirPin2, OUTPUT);
  pinMode(speedPinL, OUTPUT);
  pinMode(LeftMotorDirPin1, OUTPUT);
  pinMode(LeftMotorDirPin2, OUTPUT);
  pinMode(speedPinR, OUTPUT);
  pinMode(RightMotorDirPin1B, OUTPUT);
  pinMode(RightMotorDirPin2B, OUTPUT);
  pinMode(speedPinLB, OUTPUT);
  pinMode(LeftMotorDirPin1B, OUTPUT);
  pinMode(LeftMotorDirPin2B, OUTPUT);
  pinMode(speedPinRB, OUTPUT);

  pinMode(Trig_PIN, OUTPUT);
  pinMode(Echo_PIN, INPUT);
  digitalWrite(Trig_PIN, LOW);

  pinMode(sensor1, INPUT);
  pinMode(sensor2, INPUT);
  pinMode(sensor3, INPUT);
  pinMode(sensor4, INPUT);
  pinMode(sensor5, INPUT);

  stop_Stop();
}

void loop() {
  // =========================================================
  // 1. PRIORIDAD MÁXIMA: EVITAR SALIRSE DEL RING
  // =========================================================
  int s0 = !digitalRead(sensor1);
  int s1 = !digitalRead(sensor2);
  int s2 = !digitalRead(sensor3);
  int s3 = !digitalRead(sensor4);
  int s4 = !digitalRead(sensor5);

  if (s0 == 1 || s1 == 1 || s2 == 1 || s3 == 1 || s4 == 1) {
    go_Back();
    set_Motorspeed(ESCAPE_SPEED, ESCAPE_SPEED, ESCAPE_SPEED, ESCAPE_SPEED);
    delay(400);

    go_Right();
    set_Motorspeed(ESCAPE_SPEED, ESCAPE_SPEED, ESCAPE_SPEED, ESCAPE_SPEED);
    delay(480);

    go_Advance();
    set_Motorspeed(ESCAPE_SPEED, ESCAPE_SPEED, ESCAPE_SPEED, ESCAPE_SPEED);
    delay(250);

    return;
  }

  // =========================================================
  // 2. LECTURA DEL ULTRASONIDO CON FILTRO DE CONFIRMACIÓN
  // =========================================================
  int distancia_leida = watch();

  if (distancia_leida == 999 || distancia_leida > distancelimit) {
    contador_perdidos++;
    deteccion_confirmada = false;

    if (contador_perdidos >= 8) {
      ultima_distancia = 999;
    }
  } else {
    if (!deteccion_confirmada) {
      deteccion_confirmada = true;
    } else {
      ultima_distancia = distancia_leida;
      contador_perdidos = 0;
    }
  }

  // =========================================================
  // 3. LÓGICA DE MOVIMIENTO
  // =========================================================
  if (ultima_distancia > 0 && ultima_distancia <= distancelimit) {
    go_Advance();
    set_Motorspeed(high_speed, high_speed, high_speed, high_speed);
  } else {
    go_Right();
    set_Motorspeed(mid_speed, mid_speed, mid_speed, mid_speed);
  }
}

int watch() {
  long echo_distance;

  digitalWrite(Trig_PIN, LOW);
  delayMicroseconds(10);

  digitalWrite(Trig_PIN, HIGH);
  delayMicroseconds(15);
  digitalWrite(Trig_PIN, LOW);

  echo_distance = pulseIn(Echo_PIN, HIGH, 10000);

  if (echo_distance == 0) {
    return 999;
  }

  echo_distance = echo_distance * 0.01657;
  return round(echo_distance);
}

void go_Advance() { FR_fwd(); FL_fwd(); RR_fwd(); RL_fwd(); }
void go_Back()    { FR_bck(); FL_bck(); RR_bck(); RL_bck(); }
void go_Left()    { FR_fwd(); FL_bck(); RR_fwd(); RL_bck(); }
void go_Right()   { FR_bck(); FL_fwd(); RR_bck(); RL_fwd(); }

void stop_Stop() {
  digitalWrite(RightMotorDirPin1, LOW); digitalWrite(RightMotorDirPin2, LOW);
  digitalWrite(LeftMotorDirPin1, LOW); digitalWrite(LeftMotorDirPin2, LOW);
  digitalWrite(RightMotorDirPin1B, LOW); digitalWrite(RightMotorDirPin2B, LOW);
  digitalWrite(LeftMotorDirPin1B, LOW); digitalWrite(LeftMotorDirPin2B, LOW);
  set_Motorspeed(0,0,0,0);
}

void set_Motorspeed(int leftFront, int rightFront, int leftBack, int rightBack) {
  analogWrite(speedPinL, leftFront);
  analogWrite(speedPinR, rightFront);
  analogWrite(speedPinLB, leftBack);
  analogWrite(speedPinRB, rightBack);
}

void FR_fwd() { digitalWrite(RightMotorDirPin1, LOW); digitalWrite(RightMotorDirPin2, HIGH); }
void FR_bck() { digitalWrite(RightMotorDirPin1, HIGH); digitalWrite(RightMotorDirPin2, LOW); }
void FL_fwd() { digitalWrite(LeftMotorDirPin1, LOW); digitalWrite(LeftMotorDirPin2, HIGH); }
void FL_bck() { digitalWrite(LeftMotorDirPin1, HIGH); digitalWrite(LeftMotorDirPin2, LOW); }
void RR_fwd() { digitalWrite(RightMotorDirPin1B, LOW); digitalWrite(RightMotorDirPin2B, HIGH); }
void RR_bck() { digitalWrite(RightMotorDirPin1B, HIGH); digitalWrite(RightMotorDirPin2B, LOW); }
void RL_fwd() { digitalWrite(LeftMotorDirPin1B, LOW); digitalWrite(LeftMotorDirPin2B, HIGH); }
void RL_bck() { digitalWrite(LeftMotorDirPin1B, HIGH); digitalWrite(LeftMotorDirPin2B, LOW); }
