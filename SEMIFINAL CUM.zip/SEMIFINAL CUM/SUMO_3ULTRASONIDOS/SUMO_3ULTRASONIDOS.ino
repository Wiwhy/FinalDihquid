double mul_speed = 1.15;

double high_speed = 80 * mul_speed;
double mid_speed = 50 * mul_speed;
double low_speed = 25 * mul_speed;

int ESCAPE_SPEED = 220;

#define speedPinR 9
#define RightMotorDirPin1  22
#define RightMotorDirPin2  24
#define LeftMotorDirPin1  26
#define LeftMotorDirPin2  28
#define speedPinL 10

#define speedPinRB 11
#define RightMotorDirPin1B  5
#define RightMotorDirPin2B 6
#define LeftMotorDirPin1B 7
#define LeftMotorDirPin2B 8
#define speedPinLB 12

#define Echo_CENTER    31
#define Trig_CENTER    30
#define Echo_LEFT      33
#define Trig_LEFT      32
#define Echo_RIGHT     35
#define Trig_RIGHT     34

#define sensor1   A4
#define sensor2   A3
#define sensor3   A2
#define sensor4   A1
#define sensor5   A0

const int distancelimit = 150;
#define US_TIMEOUT 9000

#define BUSQUEDA   0
#define GIRO_IZQ   1
#define GIRO_DER   2
#define ATAQUE     3

int estado = BUSQUEDA;
int turno = 0;
int contador_perdidos = 0;

const int trigPins[3] = {Trig_LEFT, Trig_RIGHT, Trig_CENTER};
const int echoPins[3] = {Echo_LEFT, Echo_RIGHT, Echo_CENTER};

void setup() {
  pinMode(RightMotorDirPin1, OUTPUT);
  pinMode(RightMotorDirPin2, OUTPUT);
  pinMode(speedPinL, OUTPUT);
  pinMode(LeftMotorDirPin1, OUTPUT);
  pinMode(LeftMotorDirPin2, OUTPUT);
  pinMode(speedPinR, OUTPUT);
  pinMode(RightMotorDirPin1B, OUTPUT);
  pinMode(RightMotorDirPin2B, OUTPUT);
  pinMode(speedPinLB, OUTPUT);
  pinMode(LeftMotorDirPin1B, OUTPUT);
  pinMode(LeftMotorDirPin2B, OUTPUT);
  pinMode(speedPinRB, OUTPUT);

  for (int i = 0; i < 3; i++) {
    pinMode(trigPins[i], OUTPUT);
    pinMode(echoPins[i], INPUT);
    digitalWrite(trigPins[i], LOW);
  }

  pinMode(sensor1, INPUT);
  pinMode(sensor2, INPUT);
  pinMode(sensor3, INPUT);
  pinMode(sensor4, INPUT);
  pinMode(sensor5, INPUT);

  stop_Stop();
}

void loop() {
  // =========================================================
  // 1. PRIORIDAD MÁXIMA: EVITAR SALIRSE DEL RING
  // =========================================================
  int s0 = !digitalRead(sensor1);
  int s1 = !digitalRead(sensor2);
  int s2 = !digitalRead(sensor3);
  int s3 = !digitalRead(sensor4);
  int s4 = !digitalRead(sensor5);

  if (s0 == 1 || s1 == 1 || s2 == 1 || s3 == 1 || s4 == 1) {
    // Retrocede para alejarse del borde
    go_Back();
    set_Motorspeed(ESCAPE_SPEED, ESCAPE_SPEED, ESCAPE_SPEED, ESCAPE_SPEED);
    delay(400);

    // Gira 180°
    go_Right();
    set_Motorspeed(ESCAPE_SPEED, ESCAPE_SPEED, ESCAPE_SPEED, ESCAPE_SPEED);
    delay(620);

    estado = BUSQUEDA;
    turno = 0;
    contador_perdidos = 0;
    return;
  }

  // =========================================================
  // 2. DISPARO Y LÓGICA SEGÚN ESTADO
  // =========================================================
  int lectura;

  switch (estado) {

    case BUSQUEDA:
      lectura = watchSensor(trigPins[turno], echoPins[turno]);

      if (lectura > 0 && lectura <= distancelimit) {
        if (turno == 0) {
          estado = GIRO_IZQ;
          contador_perdidos = 0;
        } else if (turno == 1) {
          estado = GIRO_DER;
          contador_perdidos = 0;
        } else {
          estado = ATAQUE;
          contador_perdidos = 0;
        }
      } else {
        turno = (turno + 1) % 3;
      }
      break;

    case GIRO_IZQ:
    case GIRO_DER:
      lectura = watchSensor(Trig_CENTER, Echo_CENTER);

      if (lectura > 0 && lectura <= distancelimit) {
        estado = ATAQUE;
        contador_perdidos = 0;
      } else {
        contador_perdidos++;
        if (contador_perdidos >= 50) {
          estado = BUSQUEDA;
          turno = 0;
          contador_perdidos = 0;
        }
      }
      break;

    case ATAQUE:
      lectura = watchSensor(Trig_CENTER, Echo_CENTER);

      if (lectura > 0 && lectura <= distancelimit) {
        contador_perdidos = 0;
      } else {
        contador_perdidos++;
        if (contador_perdidos >= 8) {
          estado = BUSQUEDA;
          turno = 0;
          contador_perdidos = 0;
        }
      }
      break;
  }

  // =========================================================
  // 3. MOVIMIENTO SEGÚN ESTADO
  // =========================================================
  switch (estado) {
    case ATAQUE:
      go_Advance();
      set_Motorspeed(high_speed, high_speed, high_speed, high_speed);
      break;

    case GIRO_IZQ:
      go_Left();
      set_Motorspeed(mid_speed, mid_speed, mid_speed, mid_speed);
      break;

    case GIRO_DER:
      go_Right();
      set_Motorspeed(mid_speed, mid_speed, mid_speed, mid_speed);
      break;

    case BUSQUEDA:
    default:
      go_Right();
      set_Motorspeed(mid_speed, mid_speed, mid_speed, mid_speed);
      break;
  }
}

int watchSensor(int trigPin, int echoPin) {
  long echo_distance;

  digitalWrite(trigPin, LOW);
  delayMicroseconds(10);

  digitalWrite(trigPin, HIGH);
  delayMicroseconds(15);
  digitalWrite(trigPin, LOW);

  echo_distance = pulseIn(echoPin, HIGH, US_TIMEOUT);

  if (echo_distance == 0) return 999;

  echo_distance = echo_distance * 0.01657;
  return round(echo_distance);
}

void go_Advance() { FR_fwd(); FL_fwd(); RR_fwd(); RL_fwd(); }
void go_Back()    { FR_bck(); FL_bck(); RR_bck(); RL_bck(); }
void go_Left()    { FR_fwd(); FL_bck(); RR_fwd(); RL_bck(); }
void go_Right()   { FR_bck(); FL_fwd(); RR_bck(); RL_fwd(); }

void stop_Stop() {
  digitalWrite(RightMotorDirPin1, LOW); digitalWrite(RightMotorDirPin2, LOW);
  digitalWrite(LeftMotorDirPin1, LOW); digitalWrite(LeftMotorDirPin2, LOW);
  digitalWrite(RightMotorDirPin1B, LOW); digitalWrite(RightMotorDirPin2B, LOW);
  digitalWrite(LeftMotorDirPin1B, LOW); digitalWrite(LeftMotorDirPin2B, LOW);
  set_Motorspeed(0,0,0,0);
}

void set_Motorspeed(int leftFront, int rightFront, int leftBack, int rightBack) {
  analogWrite(speedPinL, leftFront);
  analogWrite(speedPinR, rightFront);
  analogWrite(speedPinLB, leftBack);
  analogWrite(speedPinRB, rightBack);
}

void FR_fwd() { digitalWrite(RightMotorDirPin1, LOW); digitalWrite(RightMotorDirPin2, HIGH); }
void FR_bck() { digitalWrite(RightMotorDirPin1, HIGH); digitalWrite(RightMotorDirPin2, LOW); }
void FL_fwd() { digitalWrite(LeftMotorDirPin1, LOW); digitalWrite(LeftMotorDirPin2, HIGH); }
void FL_bck() { digitalWrite(LeftMotorDirPin1, HIGH); digitalWrite(LeftMotorDirPin2, LOW); }
void RR_fwd() { digitalWrite(RightMotorDirPin1B, LOW); digitalWrite(RightMotorDirPin2B, HIGH); }
void RR_bck() { digitalWrite(RightMotorDirPin1B, HIGH); digitalWrite(RightMotorDirPin2B, LOW); }
void RL_fwd() { digitalWrite(LeftMotorDirPin1B, LOW); digitalWrite(LeftMotorDirPin2B, HIGH); }
void RL_bck() { digitalWrite(LeftMotorDirPin1B, HIGH); digitalWrite(LeftMotorDirPin2B, LOW); }
