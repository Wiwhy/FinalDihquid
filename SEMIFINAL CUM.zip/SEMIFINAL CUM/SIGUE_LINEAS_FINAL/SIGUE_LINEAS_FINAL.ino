#define MAX_SPEED  170
#define BASE_SPEED 150   // Velocidad en rectas perfectas
#define MIN_SPEED  0     // Velocidad base en giro extremo (rotación pura)
#define speedPinR 9
#define RightMotorDirPin1 22
#define RightMotorDirPin2 24
#define LeftMotorDirPin1 26
#define LeftMotorDirPin2 28
#define speedPinL 10
#define speedPinRB 11
#define RightMotorDirPin1B 5
#define RightMotorDirPin2B 6
#define LeftMotorDirPin1B 7
#define LeftMotorDirPin2B 8
#define speedPinLB 12
#define sensor1 A4 // Left most sensor
#define sensor2 A3 // 2nd Left sensor
#define sensor3 A2 // Center sensor
#define sensor4 A1 // 2nd Right sensor
#define sensor5 A0 // Right most sensor
// ================= PID =================
float Kp = 0.375;
float Ki = 0.0;
float Kd = 5;
float P = 0, I = 0, D = 0, lastError = 0;
float filteredD = 0;
#define D_FILTER 0.3    // Suavizado derivativo (0.0=máx filtro, 1.0=sin filtro)
#define I_MAX 2000
// ========================================
/* ============ Motor control ============ */
void FR_fwd(int speed) {
  digitalWrite(RightMotorDirPin1, LOW);
  digitalWrite(RightMotorDirPin2, HIGH);
  analogWrite(speedPinR, speed);
}
void FR_bck(int speed) {
  digitalWrite(RightMotorDirPin1, HIGH);
  digitalWrite(RightMotorDirPin2, LOW);
  analogWrite(speedPinR, speed);
}
void FL_fwd(int speed) {
  digitalWrite(LeftMotorDirPin1, LOW);
  digitalWrite(LeftMotorDirPin2, HIGH);
  analogWrite(speedPinL, speed);
}
void FL_bck(int speed) {
  digitalWrite(LeftMotorDirPin1, HIGH);
  digitalWrite(LeftMotorDirPin2, LOW);
  analogWrite(speedPinL, speed);
}
void RR_fwd(int speed) {
  digitalWrite(RightMotorDirPin1B, LOW);
  digitalWrite(RightMotorDirPin2B, HIGH);
  analogWrite(speedPinRB, speed);
}
void RR_bck(int speed) {
  digitalWrite(RightMotorDirPin1B, HIGH);
  digitalWrite(RightMotorDirPin2B, LOW);
  analogWrite(speedPinRB, speed);
}
void RL_fwd(int speed) {
  digitalWrite(LeftMotorDirPin1B, LOW);
  digitalWrite(LeftMotorDirPin2B, HIGH);
  analogWrite(speedPinLB, speed);
}
void RL_bck(int speed) {
  digitalWrite(LeftMotorDirPin1B, HIGH);
  digitalWrite(LeftMotorDirPin2B, LOW);
  analogWrite(speedPinLB, speed);
}
void stop_bot() {
  analogWrite(speedPinLB, 0);
  analogWrite(speedPinRB, 0);
  analogWrite(speedPinL, 0);
  analogWrite(speedPinR, 0);
  digitalWrite(RightMotorDirPin1B, LOW);
  digitalWrite(RightMotorDirPin2B, LOW);
  digitalWrite(LeftMotorDirPin1B, LOW);
  digitalWrite(LeftMotorDirPin2B, LOW);
  digitalWrite(RightMotorDirPin1, LOW);
  digitalWrite(RightMotorDirPin2, LOW);
  digitalWrite(LeftMotorDirPin1, LOW);
  digitalWrite(LeftMotorDirPin2, LOW);
  delay(40);
}
void init_GPIO() {
  pinMode(RightMotorDirPin1, OUTPUT);
  pinMode(RightMotorDirPin2, OUTPUT);
  pinMode(speedPinL, OUTPUT);
  pinMode(LeftMotorDirPin1, OUTPUT);
  pinMode(LeftMotorDirPin2, OUTPUT);
  pinMode(speedPinR, OUTPUT);
  pinMode(RightMotorDirPin1B, OUTPUT);
  pinMode(RightMotorDirPin2B, OUTPUT);
  pinMode(speedPinLB, OUTPUT);
  pinMode(LeftMotorDirPin1B, OUTPUT);
  pinMode(LeftMotorDirPin2B, OUTPUT);
  pinMode(speedPinRB, OUTPUT);
  pinMode(sensor1, INPUT);
  pinMode(sensor2, INPUT);
  pinMode(sensor3, INPUT);
  pinMode(sensor4, INPUT);
  pinMode(sensor5, INPUT);
  stop_bot();
}
void setup() {
  init_GPIO();
  Serial.begin(9600);
}
void loop() {
  tracking();
}
/* ============ PID helpers ============ */
int calcularError(int s0, int s1, int s2, int s3, int s4, int suma) {
  if (suma == 0) {
    // Línea perdida → devolver error máximo en la última dirección conocida
    return (lastError > 0) ? 250 : -250;
  }
  return (s0 * -250 + s1 * -100 + s2 * 0 + s3 * 100 + s4 * 250) / suma;
}
void setMotors(int leftSpeed, int rightSpeed) {
  leftSpeed  = constrain(leftSpeed,  -MAX_SPEED, MAX_SPEED);
  rightSpeed = constrain(rightSpeed, -MAX_SPEED, MAX_SPEED);
  if (leftSpeed >= 0) {
    FL_fwd(leftSpeed);
    RL_fwd(leftSpeed);
  } else {
    FL_bck(-leftSpeed);
    RL_bck(-leftSpeed);
  }
  if (rightSpeed >= 0) {
    FR_fwd(rightSpeed);
    RR_fwd(rightSpeed);
  } else {
    FR_bck(-rightSpeed);
    RR_bck(-rightSpeed);
  }
}
/* ============ Tracking principal ============ */
void tracking() {
  int s0 = !digitalRead(sensor1);
  int s1 = !digitalRead(sensor2);
  int s2 = !digitalRead(sensor3);
  int s3 = !digitalRead(sensor4);
  int s4 = !digitalRead(sensor5);
  int suma = s0 + s1 + s2 + s3 + s4;
  float error = calcularError(s0, s1, s2, s3, s4, suma);
  float absError = abs(error);
  // ---- Velocidad base variable ----
  // Recta centrada  → BASE_SPEED (rápido)
  // Curva fuerte    → casi 0 (rotación pura, como un pivot)
  // Transición lineal y suave entre ambos extremos
  int baseSpeed;
  if (absError < 20) {
    baseSpeed = BASE_SPEED;                              // Recta perfecta
  } else {
    baseSpeed = map(absError, 20, 250, BASE_SPEED, MIN_SPEED);
    baseSpeed = constrain(baseSpeed, MIN_SPEED, BASE_SPEED);
  }
  // ---- PID ----
  P = error;
  I += error;
  I = constrain(I, -I_MAX, I_MAX);
  if (absError < 10) I = 0;          // Reset integral cuando está centrado
  D = error - lastError;
  lastError = error;
  // Filtro low-pass sobre la derivada (suaviza saltos discretos)
  filteredD = D_FILTER * D + (1.0 - D_FILTER) * filteredD;
  float correction = (Kp * P) + (Ki * I) + (Kd * filteredD);
  int leftSpeed  = baseSpeed + correction;
  int rightSpeed = baseSpeed - correction;
  setMotors(leftSpeed, rightSpeed);
}